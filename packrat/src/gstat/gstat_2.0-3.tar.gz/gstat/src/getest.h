void get_est(DATA **data, METHOD method, DPOINT *where, double *est);
