library(testthat)
library({{{ name }}})

test_check("{{{ name }}}")
