"mvdst" <-
function (x, variant=2, inverted=FALSE) 
mvdtt(x, type="dst", variant=variant, inverted=inverted)

