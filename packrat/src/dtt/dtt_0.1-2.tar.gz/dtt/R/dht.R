"dht" <-
function (x, inverted=FALSE) 
dtt(x, type="dht", inverted=inverted)

