"dct" <-
function (x, variant=2, inverted=FALSE) 
dtt(x, type="dct", variant=variant, inverted=inverted)

