"mvdct" <-
function (x, variant=2, inverted=FALSE) 
mvdtt(x, type="dct", variant=variant, inverted=inverted)

