"mvdht" <-
function (x, inverted=FALSE) 
mvdtt(x, type="dht", inverted=inverted)

