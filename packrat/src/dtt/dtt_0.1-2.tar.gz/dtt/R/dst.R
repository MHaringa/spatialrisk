"dst" <-
function (x, variant=2, inverted=FALSE) 
dtt(x, type="dst", variant=variant, inverted=inverted)

