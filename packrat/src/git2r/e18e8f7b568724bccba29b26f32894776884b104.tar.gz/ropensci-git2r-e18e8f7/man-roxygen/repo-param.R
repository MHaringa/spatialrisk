##' @param repo a path to a repository or a \code{git_repository}
##'     object. Default is '.'
