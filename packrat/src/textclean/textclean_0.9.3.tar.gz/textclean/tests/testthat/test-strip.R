context("Checking strip")

test_that("strip ...",{


})

