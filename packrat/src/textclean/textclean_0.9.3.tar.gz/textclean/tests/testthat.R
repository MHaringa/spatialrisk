library("testthat")
library("textclean")

test_check("textclean")