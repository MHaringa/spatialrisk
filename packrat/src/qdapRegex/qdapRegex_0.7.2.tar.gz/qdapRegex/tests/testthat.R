library("testthat")
library("qdapRegex")


test_check("qdapRegex")